<h1 align="center">Добро пожаловать в b0mb3r 👋</h1>
<p align="center">
    Открытый и бесплатный СМС бомбер
    <br /><br />
    <img alt="Made with Python" src="https://img.shields.io/badge/Made%20with-Python-%23FFD242?logo=python&logoColor=white">
    <img alt="Downloads" src="https://pepy.tech/badge/b0mb3r">
    <img alt="Code style: black" src="https://img.shields.io/badge/code%20style-black-000000.svg">
</p>

## 🚀 Установка

1. Установите Python версии не ниже 3.7. Сделать это можно так:

    <h3>Для Windows</h3>

    Скачайте установщик с [официального сайта](https://www.python.org/downloads/) и запустите его. Убедитесь, что при установке отметили галочку ![Add Python to PATH](https://user-images.githubusercontent.com/42045258/69171091-557d2780-0b0c-11ea-8adf-7f819357f041.png)

    <h3>Для Android</h3>

    Установите приложение [Termux](https://play.google.com/store/apps/details?id=com.termux), запустите его и введите команду `pkg install python`.

2. Введите следующую команду ([куда?](http://comp-profi.com/kak-vyzvat-komandnuyu-stroku-ili-konsol-windows/)):

```sh
pip3 install b0mb3r -U
```

## 🚩 Запуск

Всё просто! Введите команду `b0mb3r` или `bomber` и интерфейс бомбера будет запущен. Команда доступна из любой директории.

## ❌ Устранение проблем
Если у вас возникли проблемы с b0mb3r, сначала выполните следующие базовые действия:
1. Запустите b0mb3r с флагом --repair:

    ```sh
    b0mb3r --repair
    ```
2. Перезагрузите устройство, на котором возникает проблема

## 💻 Расширенное использование

Смотреть [Wiki](https://github.com/crinny/b0mb3r/wiki).

## 📝 Лицензия
<!--- Не надо это удалять, пожалуйста 😐  -->
Проект распространяется под лицензией [Mozilla Public License 2.0](https://github.com/crinny/b0mb3r/blob/master/LICENSE). Скачивая программное обеспечение из [этого](https://github.com/crinny/b0mb3r) репозитория, вы соглашаетесь с ней. По условиям лицензии вы обязаны выкладывать исходный код ваших модификаций под той же лицензией.

**Остались вопросы?** Я в [Telegram](https://t.me/crinny). Убедитесь, что прочли [это](http://neprivet.ru/), прежде чем писать. Канал с новостями о разработке в Telegram: <https://t.me/b0mb3rch>
