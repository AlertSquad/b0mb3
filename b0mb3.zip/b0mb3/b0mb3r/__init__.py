import b0mb3r.__main__
